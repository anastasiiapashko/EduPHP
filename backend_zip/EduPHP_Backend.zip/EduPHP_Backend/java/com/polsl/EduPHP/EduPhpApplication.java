package com.polsl.EduPHP;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EduPhpApplication {

	public static void main(String[] args) {
		SpringApplication.run(EduPhpApplication.class, args);
	}

}