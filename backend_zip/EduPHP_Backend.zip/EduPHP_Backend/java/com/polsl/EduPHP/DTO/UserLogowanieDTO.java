package com.polsl.EduPHP.DTO;

import lombok.Data;

@Data
public class UserLogowanieDTO {
    private String login;
    private String passwd;
}
